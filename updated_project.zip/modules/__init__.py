"""Computer Vision Module Package."""
